# References

Erin Catto's GDC Tutorials:<br/>
[http://code.google.com/p/box2d/downloads/list](http://code.google.com/p/box2d/downloads/list)<br/>
_Collision Detection in Interactive 3D Environments,_ Gino van den Bergen,
2004<br/>
_Real-Time Collision Detection,_ Christer Ericson, 2005


*This content is licensed under
[Creative Commons Attribution 4.0](http://creativecommons.org/licenses/by/4.0/legalcode).
For details and restrictions, please see the
[Content License](md__content_license.html).*
