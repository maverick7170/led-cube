# Logo

Please feel free to make fair use the LiquidFun logo in connection with any
implementations (in your splash screens or documentation, for example).
There is no requirement to include the logo, but we appreciate your
acknowledgement. We only ask that you avoid changing the proportions of the
logo or otherwise modifying it, and that you avoid using the logo in a way
that suggests your implementation is developed by, sponsored by, or affiliated
with Fun Propulsion Labs or Google. (For example, you shouldn't use the
LiquidFun logo as your app icon, and you shouldn't use it more prominently
than your own logos or icons.)

![LiquidFun Logo bitmap](liquidfun-logo-small.png)

* [Logo in bitmap format](liquidfun-logo.png)
* [Logo in vector format](liquidfun-logo.ai)

